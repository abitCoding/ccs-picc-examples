#include<18f4550.h>
//Use High speed Crystal 
#fuses HS
//Set the frequency for delay function
#use delay(clock=20M)

void main(void){
   unsigned int16 adcRead;
   char ledBar[9]={0x00,0x01,0x03,0x07,0x0F,0x1F,0x3F,0x7F,0xFF};
   //RA0 As Input
   set_tris_a(0x01);
   //PORTD as output
   set_tris_d(0x00);
   //Set RA0 To Analog
   setup_adc_ports(AN0);
   //Select ADC internal RC Clock
   setup_adc(ADC_CLOCK_INTERNAL);
   //Select channel 0 for conversion
   set_adc_channel(0);
   while(1){
      adcRead=read_adc();
      //Wait for completion
      while(!adc_done());
      adcRead=(adcRead*9)/256;
      //Output the result to PORTD
      output_D(ledBar[adcRead]);
      delay_ms(50);
   }
}
