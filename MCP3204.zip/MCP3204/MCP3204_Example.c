#include<16F84A.h>
#use delay(clock=4M)
#fuses XT

/*MCP3204 Software SPI Pins
Selection*/
#define MCP3204_CLK  PIN_A0
#define MCP3204_DOUT PIN_A2
#define MCP3204_DIN  PIN_A1
#define MCP3204_CS   PIN_A3

/*Character LCD Pins connections*/
/*Control Pins Selection*/
#define LCD_ENABLE_PIN  PIN_B2                                    
#define LCD_RS_PIN      PIN_B0                                    
#define LCD_RW_PIN      PIN_B1  

/*4-bit Data Pins Selection*/
#define LCD_DATA4       PIN_B4                                    
#define LCD_DATA5       PIN_B5                                    
#define LCD_DATA6       PIN_B6                                    
#define LCD_DATA7       PIN_B7 

#include<mcp3204.c>
#include<lcd.c>

void main(){
   unsigned int16 val[4];
   adc_init();
   lcd_init();
   while(1){
      for(int i=0;i<4;i++) val[i]=read_analog(i);
      lcd_gotoxy(1,1);
      printf(LCD_PUTC,"CH0: %Ld CH1: %Ld   ",val[0],val[1]);
      lcd_gotoxy(1,2);
      printf(LCD_PUTC,"CH2: %Ld CH3: %Ld   ",val[2],val[3]);
      delay_ms(100);
   }
}
