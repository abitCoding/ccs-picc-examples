/*Select PIC18F4550*/
#include<18F4550.h>
/*use high speed crystal and disable WDT*/
#fuses HS,NOWDT
/*Crystal is 20MHz. It's needed for delay function*/
#use delay(clock=20M)

void main(void){
   /*Clear Port Buffer*/
   output_D(0x00);
   /*Set PORTD To Output*/
   set_tris_D(0x00);
   while(1){
      //Clear PORTD
      output_D(0x00);
      //Wait for 1S
      delay_ms(1000);
      //Set all bits of PORTD
      output_D(0xFF);
      //Wait for 1S
      delay_ms(1000);
   }
}
