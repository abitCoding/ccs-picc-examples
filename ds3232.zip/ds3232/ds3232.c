#include<16F716.h>
/*select high speed 20 MHz oscillator*/
#fuses HS
#use delay(clock=20M)

/*Force Software SPI*/
#define Device_SDA PIN_A0
#define Device_SCL  PIN_A1
#use i2c(FORCE_SW,sda=Device_SDA, scl=Device_SCL)  

/*LCD Pins Selection*/
#define LCD_RS_PIN      PIN_B1
#define LCD_RW_PIN      PIN_B2
#define LCD_ENABLE_PIN  PIN_B3

#define LCD_DATA4       PIN_B4
#define LCD_DATA5       PIN_B5
#define LCD_DATA6       PIN_B6
#define LCD_DATA7       PIN_B7

#include<lcd.c>

char myDay[8];


void dayOfWeek(char _day){
   switch(_day){
      case 1: myDay="Sunday";    break;
      case 2: myDay="Monday";    break;
      case 3: myDay="Tuesday";   break;
      case 4: myDay="Wednesday"; break;
      case 5: myDay="Thursday";  break;
      case 6: myDay="Friday";    break;
      case 7: myDay="Saturday";  break;
   }
}

void rtcControl(char address,char control){
   i2c_start();
   i2c_write(0xD0);
   i2c_write(address);
   i2c_write(control);
   i2c_stop();
}

char rtcGet(char address){
   char dataRam;
   i2c_start();
   i2c_write(0xD0);
   i2c_write(address);
   i2c_stop();
   
   i2c_start();
   i2c_write(0xD1);
   dataRam=i2c_read(false);
   i2c_stop();
   
   return dataRam;
}

void main(){
  
   char s,m,h;
   char _day,_date,_month,_years;
   char tempMSB;
   /*Disable analog inputs*/
   setup_adc_ports(NO_ANALOGS);

   lcd_init();
   /*Enable 1 second output pin*/
   rtcControl(0x0E,0b00100000);
   
   
   while(1){
      s=rtcGet(0x00);
      m=rtcGet(0x01);
      h=rtcGet(0x02);
      _day=rtcGet(0x03);
      _date=rtcGet(0x04);
      _month=rtcGet(0x05);
      _years=rtcGet(0x06);
      tempMSB=rtcGet(0x11);
      tempMSB&=0x7F;
      /*get day of week in string format*/
      dayOfWeek(_day);
      lcd_gotoxy(1,1);
      printf(LCD_PUTC,"%x:%x:%x %s",h,m,s,myDay);
      lcd_gotoxy(1,2);
      printf(LCD_PUTC,"%x/%x/20%x %d%cC ",_month,_day,_years,tempMSB,223);
      delay_ms(1000);     
   }
}
