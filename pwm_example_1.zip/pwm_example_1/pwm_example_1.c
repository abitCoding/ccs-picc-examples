
#include <18F4550.h>
#device ADC=10
#fuses HS,PLL1,CPUDIV1
#use delay(clock=20000000)

#use PWM(CCP1,FREQUENCY=10K,DUTY=0)

#define LCD_ENABLE_PIN  PIN_B2                                    
#define LCD_RS_PIN      PIN_B0                                   
#define LCD_RW_PIN      PIN_B1   

#define LCD_DATA4       PIN_B4                                    
#define LCD_DATA5       PIN_B5                                    
#define LCD_DATA6       PIN_B6                                    
#define LCD_DATA7       PIN_B7  
#include<lcd.c>

void adcSetUp(void){
   set_tris_a(0x01);
   //Set RA0 To Analog
   setup_adc_ports(AN0);
   //Select ADC internal RC Clock
   setup_adc(ADC_CLOCK_INTERNAL);
   //Select channel 0 for conversion
}

void main(void){
   unsigned long temp;
   lcd_init();
   adcSetUp();
   lcd_gotoxy(1,1);
   printf(LCD_PUTC,"PWM EXAMPLE");
   while(1){
      /*Set PWM Duty Cycle*/
      set_adc_channel(0);
      delay_ms(1);
      temp=read_adc();
      while(!adc_done());
      /*Convert from 1024 to 1000*/
      temp=(temp*1000.0)/1024;
      pwm_set_duty_percent(temp);
      lcd_gotoXy(1,2);
      printf(LCD_PUTC,"Duty Cycle %0.2f ",(float)(temp/10.0));
      delay_ms(10);
   }
}
