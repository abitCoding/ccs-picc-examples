#include<18f4550.h>
#device ADC=10

/*Use high speed clock no PLL prescaler 
no system clock post scaler */
#fuses HS,PLL1,CPUDIV1
#use delay(clock=20M)

#define LCD_ENABLE_PIN  PIN_B2                                    
#define LCD_RS_PIN      PIN_B0                                   
#define LCD_RW_PIN      PIN_B1   

#define LCD_DATA4       PIN_B4                                    
#define LCD_DATA5       PIN_B5                                    
#define LCD_DATA6       PIN_B6                                    
#define LCD_DATA7       PIN_B7  
#include<lcd.c>

void adcConfig(void){
   //RA3 As Input
   set_tris_a(0x04);
   //PORTD as output
   set_tris_d(0x00);
   //Set RA0...RA2 To Analog
   setup_adc_ports(AN0_TO_AN2);
   //Select ADC internal RC Clock
   setup_adc(ADC_CLOCK_INTERNAL);
}

float getTemperature(void){
   set_adc_channel(2);
   delay_ms(1);
   int16 analogValue=read_adc();
   while(!adc_done());
   float temperature = (analogValue*5.0)/1024;
   temperature*=100;
   return temperature;
}

void main(){
   float temp;
   lcd_init();
   adcConfig();
   
   while(1){
     lcd_gotoXy(1,1);
     printf(LCD_PUTC,"LM35 Temperature");
     lcd_gotoXy(1,2);
     temp=getTemperature();
     printf(LCD_PUTC,"%0.1f%cC %0.1f%cF  ",temp,223,((temp*1.8)+32),223);
     delay_ms(250);
   }
}
