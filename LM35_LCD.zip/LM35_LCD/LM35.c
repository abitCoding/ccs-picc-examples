#include<16F819.h>
#device adc=10
#fuses INTRC_IO,NOWDT
#use delay(clock=8M)

#define LCD_ENABLE_PIN  PIN_B2                                   
#define LCD_RS_PIN      PIN_B0                                    
#define LCD_RW_PIN      PIN_B1

#define LCD_DATA4       PIN_B4                                    
#define LCD_DATA5       PIN_B5                                    
#define LCD_DATA6       PIN_B6                                   
#define LCD_DATA7       PIN_B7                                    

#include<lcd.c>

void main(void){
   char degree=223;
   int16 adc;
   float voltage;
   
   setup_oscillator(OSC_8MHz);
   output_A(0x00);
   set_tris_A(0xFF);
   setup_adc(ADC_CLOCK_INTERNAL );
   set_adc_channel( 0 );
   setup_adc_ports(AN0_VREF_VREF);
   lcd_init();
   lcd_gotoxy(1,1);
   printf(LCD_PUTC,"Temperature:");
   
   while(1){
      adc=read_adc(ADC_START_AND_READ); 
      voltage=(adc*5.0)/1024;
      voltage=voltage-2.5;
      voltage*=100;
      lcd_gotoxy(1,2);
      printf(LCD_PUTC,"%0.2f %cC",voltage,degree);     
   }
}
