#include<18f4550.h>
/*Use high speed clock no PLL prescaler 
no system clock post scaler */
#fuses HS,PLL1,CPUDIV1
#use delay(clock=20M)

#define LCD_ENABLE_PIN  PIN_B2                                    
#define LCD_RS_PIN      PIN_B0                                   
#define LCD_RW_PIN      PIN_B1   

#define LCD_DATA4       PIN_B4                                    
#define LCD_DATA5       PIN_B5                                    
#define LCD_DATA6       PIN_B6                                    
#define LCD_DATA7       PIN_B7  
#include<lcd.c>

void main(){
   char secondCount=0;
   lcd_init();
   //First Line
   lcd_gotoxy(1,1);
   //Send characters to LCD
   printf(LCD_PUTC,"Power Up Time:");
   while(1){
      //Second Line
      lcd_gotoxy(1,2);
      //Send character to LCD
      printf(LCD_PUTC,"%u seconds ",secondCount);
      delay_ms(1000);
      secondCount++;
   }
}
