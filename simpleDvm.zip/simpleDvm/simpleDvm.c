#include<18f4550.h>
#device ADC=10

/*Use high speed clock no PLL prescaler 
no system clock post scaler */
#fuses HS,PLL1,CPUDIV1
#use delay(clock=20M)

#define LCD_ENABLE_PIN  PIN_B2                                    
#define LCD_RS_PIN      PIN_B0                                   
#define LCD_RW_PIN      PIN_B1   

#define LCD_DATA4       PIN_B4                                    
#define LCD_DATA5       PIN_B5                                    
#define LCD_DATA6       PIN_B6                                    
#define LCD_DATA7       PIN_B7  
#include<lcd.c>

void adcConfig(void){
   //RA0 As Input
   set_tris_a(0x01);
   //Set RA0 To Analog
   setup_adc_ports(AN0);
   //Select ADC internal RC Clock
   setup_adc(ADC_CLOCK_INTERNAL);
   set_adc_channel(0);
   delay_ms(10);
}

float getVoltage(void){   
   int16 analogValue=read_adc();
   while(!adc_done());
   float voltage = (analogValue*5.0)/1024;
   /*Voltage Divider*/
   voltage*=0.11;
   /*Scale Up*/
   voltage*=100;
   return voltage;
}

void main(){
   float voltage;
   lcd_init();
   adcConfig();
   
   while(1){
     lcd_gotoXy(1,1);
     printf(LCD_PUTC,"Voltage Reading");
     lcd_gotoXy(1,2);
     voltage=getVoltage();
     printf(LCD_PUTC,"%0.2f Volts  ",voltage);
     delay_ms(250);
   }
}
