#include<18f4550.h>
/*Use high speed clock no PLL prescaler 
no system clock post scaler */
#fuses HS,PLL1,CPUDIV1
#use delay(clock=20M)
#use i2c(MASTER,SDA=PIN_B0,SCL=PIN_B1,fast=10000)

#define LCD_ENABLE_PIN  PIN_D2                                    
#define LCD_RS_PIN      PIN_D0                                   
#define LCD_RW_PIN      PIN_D1   

#define LCD_DATA4       PIN_D4                                    
#define LCD_DATA5       PIN_D5                                    
#define LCD_DATA6       PIN_D6                                    
#define LCD_DATA7       PIN_D7  
#include<lcd.c>

void rtcControl(char address,char control){
   i2c_start();
   i2c_write(0xD0);
   i2c_write(address);
   i2c_write(control);
   i2c_stop();
}

char rtcGet(char address){
   char dataRam;
   i2c_start();
   i2c_write(0xD0);
   i2c_write(address);
   i2c_stop();
   
   i2c_start();
   i2c_write(0xD1);
   dataRam=i2c_read(FALSE);
   i2c_stop();
   
   return dataRam;
}

char myDay[3];
void dayOfWeek(char _day){
   switch(_day){
      case 1: myDay="Sun";    break;
      case 2: myDay="Mon";    break;
      case 3: myDay="Tue";    break;
      case 4: myDay="Wed";    break;
      case 5: myDay="Thu";    break;
      case 6: myDay="Fri";    break;
      case 7: myDay="Sat";    break;
   }
}

void main(){
   char s,m,h;
   char _day,_date,_month,_years;
   lcd_init();
   /*Enable 1 second output pin*/
   rtcControl(0x07,0x10);
   
   while(1){
     s=rtcGet(0x00);
      m=rtcGet(0x01);
      h=rtcGet(0x02);
      _day=rtcGet(0x03);
      _date=rtcGet(0x04);
      _month=rtcGet(0x05);
      _years=rtcGet(0x06);
      /*get day of week in string format*/
      dayOfWeek(_day);
      lcd_gotoxy(1,1);
      printf(LCD_PUTC,"%x:%x:%x %s",h,m,s,myDay);
      lcd_gotoxy(1,2);
      printf(LCD_PUTC,"%x/%x/20%x",_month,_date,_years);
      delay_ms(500);   
   }
}
